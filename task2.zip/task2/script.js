document.addEventListener('DOMContentLoaded', function () {
    const color1Input = document.getElementById('color1');
    const color2Input = document.getElementById('color2');
    const generateButton = document.getElementById('generate');
    const cssOutput = document.getElementById('css-output');

    generateButton.addEventListener('click', function () {
        const color1 = color1Input.value;
        const color2 = color2Input.value;

        const gradient = `linear-gradient(to right, ${color1}, ${color2})`;
        cssOutput.value = `background: ${gradient};`;

        // Apply the gradient as the background
        document.body.style.background = gradient;
    });
});
